import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from prediction_modules.logger import log_class
# import requests, json
# import re


folder_path = './log_files/'
file_name = 'log_file.txt'
logger = log_class(folder_path,file_name)

app = Flask(__name__)
model = pickle.load(open('AdaBoost_Base_ExtraTree.pkl', 'rb'))

@app.route('/')
def home():
    logger.create_log_file("rendering the home page for taking user input")
    return render_template("index.html")


@app.route('/dash', methods=['GET', 'POST'])
def dash():
    logger.create_log_file("Filled the dropdown successfully")
    # name_list,type_list,cruisin_list,address_list,location_list]
    option_list = fillDropdown()
    namelist_list = option_list[0]
    typelist_list = option_list[1]
    cruisin_list = option_list[2]
    location_list = option_list[4]
    address_list = option_list[3]
    return render_template('predictForm.html', namelist_list =namelist_list,typelist_list=typelist_list, cruisin_list=cruisin_list,address_list = address_list,location_list=location_list)

@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    	address	name	votes	location	rest_type	cuisines	cost(for_2)
    '''
    df = pd.read_csv('zom.csv')  # ,col_list)
    Restaurant_Type = request.form['Restaurant_Type']
    rest_index = gettype(Restaurant_Type,"Restaurant_Type",df)

    cuisines_Type = request.form['Cuisines']
    cuisines_index = gettype(cuisines_Type, "Cuisines",df)

    address_Type = request.form['address']
    address_index = gettype(address_Type, "address",df)

    location_Type = request.form['location']
    location_index = gettype(location_Type, "location", df)

    name_Type = request.form['name']
    name_index = gettype(name_Type, "name", df)

    #booktable = float(request.form['BookTable'])
    votes = float(request.form['Votes'])
    cost = float(request.form['Cost'])
    logger.create_log_file("Data entered by the user is received successfully")
    # features = [int(x) for x in request.form.values()]
    # final_features = [np.array(features)]
    # prediction = model.predict(final_features)
    prediction = model.predict([[ address_index,name_index, votes, location_index, rest_index, cuisines_index, cost]])
    output = round(prediction[0], 1)
    logger.create_log_file("Predicted value is : ")
    logger.create_log_file(output)
    return render_template('result.html', prediction_text='The Predicted Rating is: {}'.format(output))


def fillDropdown():
    df = pd.read_csv('zom.csv')

    nametype = df["name"].unique()
    n_list = [x for x in nametype if pd.isnull(x) == False and x != 'nan']
    name_list = get_uniquelist(n_list)
    name_list.sort()

    resttype = df["rest_type"].unique()
    t_list = [x for x in resttype if pd.isnull(x) == False and x != 'nan']
    type_list=get_uniquelist(t_list)
    type_list.sort()

    cruisin = df['cuisines'].unique()
    c_list = [x for x in cruisin if pd.isnull(x) == False and x != 'nan']
    cruisin_list = get_uniquelist(c_list)
    cruisin_list.sort()

    address = df['address'].unique()
    add_list = [x for x in address if pd.isnull(x) == False and x != 'nan']
    address_list = get_uniquelist(add_list)
    address_list.sort()

   # menuItem_list = removeEmpty(df["menu_item"].unique())
    location = df["location"].unique()
    l_list = [x for x in location if pd.isnull(x) == False and x != 'nan']
    location_list = get_uniquelist(l_list)
    location_list.sort()
    logger.create_log_file("Filled the dropdown successfully")
    finallist = [name_list,type_list,cruisin_list,address_list,location_list]
    return finallist

def get_uniquelist(input_list):
    finallist = []
    for sublist in input_list:
        res = isinstance(sublist[0], str)
        if(res == True):
            j = sublist.replace(' ', '_')
            finallist.append(j)
    finallist = list(set(finallist))
    return finallist


def gettype(value,type,df):
    if '_' in value:
        val = value.replace('_', ' ')
    else:
        val = value

    le = LabelEncoder()
    if (type == 'Restaurant_Type'):
        classes = df["rest_type"]
        type_list = [x for x in classes if pd.isnull(x) == False and x != 'nan']
        le.fit(type_list)
        integerMapping = get_integer_mapping(le)
        return integerMapping[val]
    elif (type == 'Name'):
        classes = df["name"]
        name_list = [x for x in classes if pd.isnull(x) == False and x != 'nan']
        le.fit(name_list)
        integerMapping = get_integer_mapping(le)
        return integerMapping[val]
    elif (type == 'Cuisines'):
        classes = df["cuisines"]
        type_list = [x for x in classes if pd.isnull(x) == False and x != 'nan']
        le.fit(type_list)
        integerMapping = get_integer_mapping(le)
        return integerMapping[val]
    elif (type == 'Location'):
        classes = df["location"]
        type_list = [x for x in classes if pd.isnull(x) == False and x != 'nan']
        le.fit(type_list)
        integerMapping = get_integer_mapping(le)
        return integerMapping[val]
    elif (type == 'address'):
        classes = df["address"]
        type_list = [x for x in classes if pd.isnull(x) == False and x != 'nan']
        le.fit(type_list)
        integerMapping = get_integer_mapping(le)
        return integerMapping[val]
    return 0

def get_integer_mapping(le):
    '''
    Return a dict mapping labels to their integer values
    from an SKlearn LabelEncoder
    le = a fitted SKlearn LabelEncoder
    '''
    res = {}
    for cl in le.classes_:
        res.update({cl:le.transform([cl])[0]})
    return res

if __name__ == "__main__":
    app.run(debug=True)