import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import pandas as pd

app = Flask(__name__)
model = pickle.load(open('model.pkl', 'rb'))

@app.route('/', methods=['GET', 'POST'])
def home():
    option_list = fillDropdown()
    typelist_list = option_list[0]
    cruisin_list = option_list[1]
    #menuItem_list = option_list[2]
    location_list = option_list[3]
    return render_template('index.html', typelist_list=typelist_list, cruisin_list=cruisin_list,location_list=location_list)


@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''

    Restaurant_Type = request.form['Restaurant_Type']
    rest_index = gettype(Restaurant_Type,"Restaurant_Type")

    cuisines_Type = request.form['cuisines']
    cuisines_index = gettype(cuisines_Type, "cuisines")

    menu_item_Type = request.form['menu_item']
    menu_item_index = gettype(menu_item_Type, "menu_item")

    location_Type = request.form['location']
    location_index = gettype(location_Type, "location")

    features = [int(x) for x in request.form.values()]
    final_features = [np.array(features)]
    prediction = model.predict(final_features)

    output = round(prediction[0], 1)

    return render_template('index.html', prediction_text='Your Rating is: {}'.format(output))


def fillDropdown():
    #col_list = ["listed_in(type)"]
    df = pd.read_csv('zom.csv')#,col_list)

    typelist_list =  get_uniquelist(df["rest_type"].unique())
    cruisin_list = get_uniquelist(df['cuisines'].unique())
   # menuItem_list = removeEmpty(df["menu_item"].unique())
    location_list = df["location"].unique()
    #finallist = [typelist_list,cruisin_list,menuItem_list,location_list]
    finallist = [typelist_list, cruisin_list,location_list]
    return finallist

def gettype(value,type):
    df = pd.read_csv('zom.csv')  # ,col_list)
    # if (type == 'Restaurant_Type'):
    #     newlist = replacespace(df["rest_type"].unique())
    #     return newlist.index(value)
    # elif (type == 'cuisines_Type'):
    #     newlist = replacespace(df["cuisines"].unique())
    #     return newlist.index(value)
    # elif (type == 'menu_item_Type'):
    #     newlist = replacespace(df["menu_item"].unique())
    #     return newlist.index(value)
    # elif (type == 'location_Type'):
    #     newlist = replacespace( df["location"].unique())
    #     return newlist.index(value)
    return " "

def get_uniquelist(input_list):
    finallist = []
    cleanedList = [x for x in input_list if pd.isnull(x) == False and x != 'nan']
    for sublist in cleanedList:
        res = isinstance(sublist[0], str)
        if(res == True):
            x = sublist.split(",")
            y = map(lambda x: x.strip(), x)
            for j in y:
                finallist.append(j)
    finallist = list(set(finallist))
    finallist.sort()
    return finallist

def removeEmpty(mylist):
    newlist = []
    for i in mylist:
        if i != '[]':
            newlist.append(i)
    return newlist

if __name__ == "__main__":
    app.run(debug=True)